# Top 10 challenges in data science

In this repository we will save scripts, presentations and data for our top 10 challenges